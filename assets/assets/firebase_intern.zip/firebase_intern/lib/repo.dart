import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_intern/model/student.dart';
import 'package:get/get.dart';

class DatabaseManager {
  FirebaseFirestore firestore = FirebaseFirestore.instance;
  static CollectionReference studentCollection =
      FirebaseFirestore.instance.collection('student');

  Future<void> addStudent({required Student student}) async {
    try {
      var doc = studentCollection.doc();
      student.uid = doc.id;
      doc.set(student.toMap());
    } on FirebaseException catch (error) {
      Get.snackbar("Error", error.message.toString());
    }
  }

  static Stream<List<Student>>? getAllStudentsStream() {
    try {
      List<Student> allStudents = [];
      return studentCollection.snapshots().map((event) {
        for (var element in event.docs) {
          allStudents.add(Student.fromMap(element.data() as Map<String,
              dynamic>)); // map me cast kro , student model me convert kro, list of all student add krdo
        }
        return allStudents;
      });
    } on FirebaseException catch (error) {
      Get.snackbar("Error", error.message.toString());
      return null;
    }
  }
}
