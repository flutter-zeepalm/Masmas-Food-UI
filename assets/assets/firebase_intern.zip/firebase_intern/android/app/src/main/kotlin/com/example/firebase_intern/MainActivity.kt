package com.example.firebase_intern

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
