import 'dart:convert';

class Student {
  String sid;
  String sName;
  int sClass;
  double smarks;
  String uid;
  Student({
    required this.sid,
    required this.sName,
    required this.sClass,
    required this.smarks,
    required this.uid,
  });

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'sid': sid});
    result.addAll({'sName': sName});
    result.addAll({'sClass': sClass});
    result.addAll({'smarks': smarks});
    result.addAll({'uid': uid});

    return result;
  }

  factory Student.fromMap(Map<String, dynamic> map) {
    return Student(
      sid: map['sid'] ?? '',
      sName: map['sName'] ?? '',
      sClass: map['sClass'] ?? 0,
      smarks: map['smarks'] ?? 0.0,
      uid: map['uid'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory Student.fromJson(String source) =>
      Student.fromMap(json.decode(source));
}
