import 'package:firebase_intern/model/student.dart';
import 'package:firebase_intern/repo.dart';
import 'package:firebase_intern/screens.dart/viewScreen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AddData extends StatefulWidget {
  const AddData({Key? key}) : super(key: key);

  @override
  State<AddData> createState() => _AddDataState();
}

class _AddDataState extends State<AddData> {
  DatabaseManager databaseManager = DatabaseManager();
  var sIdController = TextEditingController();
  var sNameController = TextEditingController();
  var sClassController = TextEditingController();
  var sMarksController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 100,
          ),
          const Text("Student Id"),
          TextField(
            controller: sIdController,
          ),
          const Text("Student name"),
          TextField(
            controller: sNameController,
          ),
          const Text("student class"),
          TextField(
            controller: sClassController,
          ),
          const Text("Student marks"),
          TextField(
            controller: sMarksController,
          ),
          ElevatedButton(
            onPressed: () async {
              Student student = Student(
                  sid: sIdController.text,
                  sName: sNameController.text,
                  sClass: int.parse(sClassController.text),
                  smarks: double.parse(sMarksController.text),
                  uid: '');
              await databaseManager.addStudent(student: student);
              Get.snackbar("succes", "Student added");
            },
            child: const Text("Add Feild"),
          ),
          ElevatedButton(
              onPressed: () {
                Get.to(() => ViewScreen(), transition: Transition.downToUp);
              },
              child: Text("viewScreen")),
        ],
      ),
    );
  }
}
