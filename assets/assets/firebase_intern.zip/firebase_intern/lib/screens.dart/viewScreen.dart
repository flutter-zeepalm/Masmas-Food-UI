import 'package:firebase_intern/model/student.dart';
import 'package:firebase_intern/repo.dart';
import 'package:flutter/material.dart';

class ViewScreen extends StatelessWidget {
  const ViewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder<List<Student>?>(
          stream: DatabaseManager.getAllStudentsStream(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            List<Student>? allStudents = snapshot.data;
            if (allStudents!.isEmpty) {
              return const Center(
                child: Text("No Students addded"),
              );
            }
            return Scaffold(
              body: SizedBox(
                  height: 400,
                  width: double.infinity,
                  child: ListView.builder(
                    itemCount: allStudents.length,
                    itemBuilder: (BuildContext context, int index) {
                      return ListTile(
                        title: Text(allStudents[index].sName),
                        subtitle: Text(allStudents[index].smarks.toString()),
                      );
                    },
                  )),
            );
          }),
    );
  }
}
